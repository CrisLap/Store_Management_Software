# Store Management Software

# Creation of a software for the management of a vegan shop. The software has the following features:

# * Registration of new products, with name, quantity, selling price and purchase price;
# * List of all the products contained in the stock;
# * Registration in a csv file of all activities' history (purchase and selling operations, date time included);
# * Record of the sales made;
# * Visualization of gross and net profits.


import csv
import os
from datetime import datetime
from store_functions import help_cmd
from store_functions import stock_info
from store_functions import add
from store_functions import itemize
from store_functions import sell
from store_functions import profit



cmd = None
while cmd!="close":

    cmd = input("\nInsert a command in order to perform an action (digit help to see the functions available): ")  
    
    if cmd=="sell":

        sold_dict={}
        answer="yes"
        
        while answer.lower()!="no":
            is_string,quantity=False,None

            while is_string==False:
                try:
                    product_name=input("Product name: ")  
                    if product_name.isnumeric():
                        is_string==False
                        raise ValueError("\nProduct not valid: inserted numeric value.")
                        continue
                    else:
                        is_string=True
                except ValueError as e:
                    print(e)

            while quantity==None or quantity <=0:
                try:
                    quantity=int(input("Quantity: "))
                    if quantity <= 0:
                        print( "\nValue entered is minus or equal to zero. Enter a positive value for quantity")
                except ValueError:
                    print("\nQuantity not valid: insert integer number")
    
            #function sell is called: if stop=1 the sale is registered in a temporary dictionary sold_dict
            #and the user is asked if a new product has to be sold. If NO is selected the total selling price is shown
            stop=sell(product_name,quantity)
            stock=stock_info()
            
            if stop==1:
                sold_dict[product_name]=quantity
  
            answer=input("Do you want to insert another product?: [yes/NO]")
        
        if len(list(sold_dict.keys()))!=0:
            print("\nSALE SUCCESSFULLY REGISTERED: ")
            
        total_sold=0
        for key in list(sold_dict.keys()):
            print(f"{sold_dict[key]} X {key}: €{stock[key]['Selling price']}")
            total_sold+=(stock[key]['Selling price']*sold_dict[key])
        print(f"\nTotal: €{total_sold:.2f}")





    elif cmd=="profits":

        profit()


    
    elif cmd=="add":
    
        is_string,quantity=False,None
        while is_string==False:
            try:
                product_name=input("Product name: ")  
                if product_name.isnumeric():
                    is_string==False
                    raise ValueError("\nInvalid product entry: numeric value entered") 
                    continue
                else:
                    is_string=True
            except ValueError as e:
                print(e)

        while quantity==None or quantity <=0:
            try:
                quantity=int(input("Quantity: ")) 
                if quantity <= 0:
                    print( "\nValue entered is minus or equal to zero. Enter a positive value for quantity")
            except ValueError:
                print("\nQuantity not valid: insert integer number")
                    
        #function add is called
        add(product_name,quantity)





    elif cmd=="list":
    
        itemize()
        



    elif cmd=="help":
    
        help_cmd()




    
    elif cmd=="close":

        print("Good Bye, see you again when you want to perform another action")
        break
    else:
        print("\nCommand not valid")
        help_cmd()